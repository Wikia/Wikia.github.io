"""
post processing methods
"""

import re
import unicodedata

from .constants import (
    DD_MM_YYYY_REGEX,
    ELEMENT_KEY_IMAGE_SOURCES,
    ELEMENT_KEY_LINK_URLS,
    JSON_PROPERTY_DAY,
    JSON_PROPERTY_MONTH,
    JSON_PROPERTY_NUMBER,
    JSON_PROPERTY_PROCESSED_KEY,
    JSON_PROPERTY_PROCESSED_VALUE,
    JSON_PROPERTY_RAW_KEY,
    JSON_PROPERTY_RAW_VALUE,
    JSON_PROPERTY_VALUE_TYPE,
    JSON_PROPERTY_VALUES,
    JSON_PROPERTY_YEAR,
    JSON_PROPERTY_URLS,
    MM_DD_YYYY_REGEX,
    MONTH_TO_INT_MAPPING,
    NUMBER_REGEX,
    TRAILING_PUNC_TO_STRIP,
    UNIT_SUFFIX_TO_MULTIPLIER_MAPPING,
    VALUE_TYPE_DATE,
    VALUE_TYPE_NUMBER,
    VALUE_TYPE_STRING
)
from .shared_methods import create_key_value_json


def post_process_infobox(infobox, key_dict, type_dict):
    clean_keys_and_values(infobox)
    fix_previous_next_elements(infobox)

    # Should be called after key/values have been cleaned
    add_type_field(infobox, key_dict, type_dict)
    parse_values_based_on_type(infobox)
    # Split certain fields by comma (e.g. writers, but not description)


# Since "previous"/"next" are usually vertical key:values,
# attempt to correct cases where we have previous:next and
# previous_value:next_value as key:value pairs. We attempt to
# convert this to previous:previous_value and next:next_value
def fix_previous_next_elements(infobox):

    # Give a pair of incorrectly formatted elements for previous/next, attempt to fix it
    def create_new_elements(prev_element, next_element):
        try:
            # Construct the 'previous' element from the two keys
            new_prev_element = create_key_value_json(
                prev_element[JSON_PROPERTY_RAW_KEY],
                prev_element[JSON_PROPERTY_URLS],
                [(next_element[JSON_PROPERTY_RAW_KEY],
                  next_element[JSON_PROPERTY_URLS])]
            )
            new_prev_element[JSON_PROPERTY_PROCESSED_KEY] = prev_element[JSON_PROPERTY_PROCESSED_KEY]
            new_prev_element[JSON_PROPERTY_VALUES][0][JSON_PROPERTY_URLS] = next_element[JSON_PROPERTY_URLS]
            new_prev_element[JSON_PROPERTY_VALUES][0][JSON_PROPERTY_PROCESSED_VALUE] = \
                next_element[JSON_PROPERTY_PROCESSED_KEY]

            # Construct the 'next' element from the two values
            prev_value = prev_element[JSON_PROPERTY_VALUES][0]
            next_value = next_element[JSON_PROPERTY_VALUES][0]
            new_next_element = create_key_value_json(
                prev_value[JSON_PROPERTY_RAW_VALUE],
                prev_value[JSON_PROPERTY_URLS],
                [(next_value[JSON_PROPERTY_RAW_VALUE], next_value[JSON_PROPERTY_URLS])]
            )
            new_next_element[JSON_PROPERTY_PROCESSED_KEY] = prev_value[JSON_PROPERTY_PROCESSED_VALUE]
            new_next_element[JSON_PROPERTY_VALUES][0][JSON_PROPERTY_URLS] = next_value[JSON_PROPERTY_URLS]
            new_next_element[JSON_PROPERTY_VALUES][0][JSON_PROPERTY_PROCESSED_VALUE] = \
                next_value[JSON_PROPERTY_PROCESSED_VALUE]

            return new_prev_element, new_next_element
        except:
            return prev_element, next_element

    # For each element, check if it fits the specific criteria for fixing. If so, create
    # the new elements, and store them in a list
    changes = []
    for i, element in enumerate(infobox):

        # Extract the key:values from the element
        if (JSON_PROPERTY_PROCESSED_KEY not in element) or (JSON_PROPERTY_VALUES not in element):
            continue
        key = element[JSON_PROPERTY_PROCESSED_KEY]
        values = [val_element[JSON_PROPERTY_PROCESSED_VALUE]
                  for val_element in element[JSON_PROPERTY_VALUES]]

        # Ensure we have 'previous':'next' as the key:value pair, and that there's an element to combine it with
        valid_current_element = (key == 'previous') and (
            len(values) == 1) and (values[0] == 'next')
        valid_next_element = (len(infobox) >= i+2) and (
            JSON_PROPERTY_VALUES in infobox[i+1]) and (len(infobox[i+1][JSON_PROPERTY_VALUES]) == 1)
        if valid_current_element and valid_next_element:
            new_prev_element, new_next_element = create_new_elements(
                element, infobox[i + 1])
            changes.append((i, new_prev_element, new_next_element))

    # Overwrite the old elements with our new elements
    for i, new_prev_element, new_next_element in changes:
        infobox[i] = new_prev_element
        infobox[i + 1] = new_next_element


# Performs a cleaning operation to every raw key and value
def clean_keys_and_values(infobox):

    def clean_string(string):
        # Standardize characters (e.g. \xa0 -> space)
        # http://www.unicode.org/reports/tr15/#Normalization_Forms_Table
        # Normalization Form KD (NFKD) | Compatibility Decomposition
        string = unicodedata.normalize("NFKD", string)

        # Strip any number tags like "[1]"
        bracket_regex = r"\[\d*\]"
        string = re.sub(bracket_regex, "", string).strip()

        # Strip any trailing specific punctuation
        if (len(string) > 0) and (string[0] in TRAILING_PUNC_TO_STRIP):
            string = string[1:].strip()
        if (len(string) > 0) and (string[-1] in TRAILING_PUNC_TO_STRIP):
            string = string[:-1].strip()

        # Lowercase the string to standardize it
        return string.lower()

    for element in infobox:
        # If there's no raw key, it's system-defined, so skip it
        if JSON_PROPERTY_RAW_KEY not in element:
            continue
        # Process the key
        raw_key = element[JSON_PROPERTY_RAW_KEY]
        element[JSON_PROPERTY_PROCESSED_KEY] = clean_string(raw_key)
        # Process each of the values
        for value in element[JSON_PROPERTY_VALUES]:
            raw_value = value[JSON_PROPERTY_RAW_VALUE]
            value[JSON_PROPERTY_PROCESSED_VALUE] = clean_string(raw_value)


def add_type_field(infobox, key_dict, type_dict):
    for element in infobox:

        # Skip system-defined elements
        key = element[JSON_PROPERTY_PROCESSED_KEY]
        if key in {ELEMENT_KEY_LINK_URLS, ELEMENT_KEY_IMAGE_SOURCES}:
            continue

        # Handle the case where we have a hard-coded mapping based on the key
        # This updates the processed key to the mapped key, and sets the value types if possible
        if key in key_dict:
            new_key = key_dict[key]
            element[JSON_PROPERTY_PROCESSED_KEY] = new_key
            if new_key in type_dict:
                value_type = type_dict[new_key]
                for val in element[JSON_PROPERTY_VALUES]:
                    val[JSON_PROPERTY_VALUE_TYPE] = value_type

        # Handle case where we have to parse the type based on the value's string
        # Re-process values from above to catch potential mistakes
        # (e.g. we marked a date as a person above due to bad formatting)
        for value_element in element[JSON_PROPERTY_VALUES]:
            val = value_element[JSON_PROPERTY_PROCESSED_VALUE]

            # Inspect value to see if it matches a date regex
            date_regex = DD_MM_YYYY_REGEX + "|" + MM_DD_YYYY_REGEX
            date_match = re.match(date_regex, val, re.IGNORECASE)
            if date_match is not None:
                value_element[JSON_PROPERTY_VALUE_TYPE] = VALUE_TYPE_DATE
                continue

            # Inspect all values to see if they match a number regex. I Remove commas
            # for cases like "100,000", but this breaks cases where commas are the decimal.
            # Since the former case is more common, I chose to fix that one.
            stripped_val = val.replace(",", "")
            number_match = re.match(NUMBER_REGEX, stripped_val)
            if number_match is not None:
                value_element[JSON_PROPERTY_VALUE_TYPE] = VALUE_TYPE_NUMBER
                continue

            # Mark all remaining typeless values as strings
            if JSON_PROPERTY_VALUE_TYPE not in value_element:
                value_element[JSON_PROPERTY_VALUE_TYPE] = VALUE_TYPE_STRING


def parse_values_based_on_type(infobox):

    def parse_date(string, element):
        matches = re.findall(MM_DD_YYYY_REGEX, string, re.IGNORECASE)
        if (matches is not None) and (len(matches) == 1) and (len(matches[0]) == 10):
            element[JSON_PROPERTY_DAY] = int(matches[0][6])
            month = matches[0][1].lower()
            element[JSON_PROPERTY_MONTH] = int(month) if (
                month not in MONTH_TO_INT_MAPPING) else MONTH_TO_INT_MAPPING[month]
            element[JSON_PROPERTY_YEAR] = int(matches[0][9])
            return

        matches = re.findall(DD_MM_YYYY_REGEX, string, re.IGNORECASE)
        if (matches is not None) and (len(matches) == 1) and (len(matches[0]) == 10):
            element[JSON_PROPERTY_DAY] = int(matches[0][2])
            month = matches[0][5].lower()
            element[JSON_PROPERTY_MONTH] = int(month) if (
                month not in MONTH_TO_INT_MAPPING) else MONTH_TO_INT_MAPPING[month]
            element[JSON_PROPERTY_YEAR] = int(matches[0][9])
            return

    def parse_number(string, element):
        string = string.replace(",", "")
        matches = re.findall(NUMBER_REGEX, string, re.IGNORECASE)
        if (matches is not None) and (len(matches) == 1) and (len(matches[0]) == 3):
            num = float(matches[0][1])
            multiplier = matches[0][2]
            multiplier = 1 if (multiplier not in UNIT_SUFFIX_TO_MULTIPLIER_MAPPING) else (
                UNIT_SUFFIX_TO_MULTIPLIER_MAPPING[multiplier])
            element[JSON_PROPERTY_NUMBER] = num * multiplier

    for key_value_pair in infobox:

        # Skip system-defined elements
        key = key_value_pair[JSON_PROPERTY_PROCESSED_KEY]
        if key in {ELEMENT_KEY_IMAGE_SOURCES, ELEMENT_KEY_LINK_URLS}:
            continue

        # For each non-system element, attempt to parse the value based on its type
        for value_element in key_value_pair[JSON_PROPERTY_VALUES]:
            value = value_element[JSON_PROPERTY_PROCESSED_VALUE]
            value_type = value_element[JSON_PROPERTY_VALUE_TYPE]
            if value_type == VALUE_TYPE_DATE:
                parse_date(value, value_element)
            elif value_type == VALUE_TYPE_NUMBER:
                parse_number(value, value_element)
