import logging

from bs4 import BeautifulSoup

from .parse_methods import (
    extract_infobox,
    extract_infobox_from_aside,
    extract_infobox_from_div,
    extract_infobox_from_table
)
from .infobox_type import InfoboxType

logger = logging.getLogger(__name__)


def parse(html, key_dict, type_dict):
    try:
        return extract_infobox(html, key_dict, type_dict)
    except Exception as e:
        logger.error("Exception thrown while parsing infobox")
        logger.exception(e)


def get_infobox_type(html_string):
    bs = BeautifulSoup(html_string, 'html.parser')
    infobox_type = InfoboxType.missing

    if extract_infobox_from_aside(bs):
        infobox_type = InfoboxType.aside
    elif extract_infobox_from_div(bs):
        infobox_type = InfoboxType.div
    elif extract_infobox_from_table(bs):
        infobox_type = InfoboxType.table

    return infobox_type
