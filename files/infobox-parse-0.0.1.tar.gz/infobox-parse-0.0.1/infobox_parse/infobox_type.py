from enum import Enum


class InfoboxType(Enum):
    missing = 0
    aside = 1
    div = 2
    table = 3
