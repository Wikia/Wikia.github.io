"""
Shared Parsing Methods
"""

from bs4 import BeautifulSoup

from .constants import (
    JSON_PROPERTY_RAW_KEY,
    JSON_PROPERTY_URLS,
    JSON_PROPERTY_VALUES,
    JSON_PROPERTY_RAW_VALUE,
    JSON_PROPERTY_PROCESSED_KEY,
    ELEMENT_KEY_IMAGE_SOURCES,
    ELEMENT_KEY_LINK_URLS,
    STRIP_TAGS
)


def create_key_value_json(key, key_urls, value_urls_pairs):
    # If any provided values aren't correct, return None
    if (key is None) or (key_urls is None) or (value_urls_pairs is None) or (len(value_urls_pairs) == 0):
        return None

    return {
        JSON_PROPERTY_RAW_KEY: key,
        JSON_PROPERTY_URLS: key_urls,
        JSON_PROPERTY_VALUES: [{
            JSON_PROPERTY_RAW_VALUE: value,
            JSON_PROPERTY_URLS: value_urls
        } for value, value_urls in value_urls_pairs]
    }


def extract_urls(html_soup, infobox):
    # Extract all the image sources from <img> tags
    infobox.append({
        JSON_PROPERTY_PROCESSED_KEY: ELEMENT_KEY_IMAGE_SOURCES,
        JSON_PROPERTY_URLS: [img['src'] for img in html_soup.findChildren(
            "img") if img.has_attr('src')]
    })

    # Extract all the urls from <a> tags
    infobox.append({
        JSON_PROPERTY_PROCESSED_KEY: ELEMENT_KEY_LINK_URLS,
        JSON_PROPERTY_URLS: [a['href']
                             for a in html_soup.findChildren("a") if a.has_attr('href')]
    })


def extract_raw_text(element_html):
    # If they didn't give us anything, return None
    if element_html is None:
        return None

    # If the element isn't a string, remove unnecessary formatting tags from the HTML
    if not isinstance(element_html, str):
        for tag in STRIP_TAGS:
            for match in element_html.findAll(tag):
                match.unwrap()
        element_html = BeautifulSoup(str(element_html), 'html.parser').find()

    # Recursively explore HTML until we get to the raw text
    return extract_raw_text_recurse(element_html)


# Recursively explores the HTML until it reaches raw text
#pylint: disable=dangerous-default-value
def extract_raw_text_recurse(element, links=[]):

    # Base Case: The element is a String
    if isinstance(element, str):
        raw_str = element.strip()  # Strip whitespace
        if len(raw_str) == 0:
            return []
        return [(raw_str, links)]

    # Remove/extract the links from the element.
    # If the element is an <a> tag, parse the element rather than its contents
    contents = [element] if (element.name == 'a') else element.contents
    element_links_pairs = extract_and_remove_links(contents)

    # This list will store the keys/values we extract
    extracted = []

    # Loop through every element, and attempt to recursively parse it
    for new_element, new_links in element_links_pairs:
        str_links_pairs = extract_raw_text_recurse(new_element, new_links)

        # If nothing could be parsed from the element, continue
        if (str_links_pairs is None) or (len(str_links_pairs) == 0):
            continue

        # If we parsed the element, append the inner elements (results in flattening nested lists)
        extracted += str_links_pairs

    # Return the extracted key:values pairs
    return extracted


# This method removes <a> tags from the element while preserving the urls that were removed.
# e.g. content: ['a ', '<a href="example1.com">dog</a>', '<a href="example2.com">house</a>', '<div>cat</div>']
# would become: [('a doghouse', ['example1.com', 'example2.com]), ('<div>cat</div>', [])
def extract_and_remove_links(element_contents):

    text = ""
    links = []
    combined_content = []

    # This loop removes <a> tags from the element's contents
    # e.g. content: ['a ', '<a href="example1.com">dog</a>', '<a href="example2.com">house</a>', '<div>cat</div>']
    # would become: [('a doghouse', ['example1.com', 'example2.com]), ('<div>cat</div>', [])
    for c in element_contents:

        # If the content is an <a> tag, add the string to the text
        # being accumulated, and save the href if it has one.
        if c.name == 'a':
            if c.has_attr('href'):
                links.append(c['href'])
            text += c.get_text()

        # If the content is a string, add it to the text we're accumulating
        elif isinstance(c, str):
            text += c

        # If we encounter a tag other than <a> or String
        else:

            # If we've accumulated some content, save it with its links
            if len(text) > 0:
                combined_content.append((text, links))
                text = ""
                links = []

            # Leave elements other than <a> and String alone
            combined_content.append((c, []))

    # Save the last element after existing the loop if necessary
    if len(text) > 0:
        combined_content.append((text, links))

    return combined_content
