"""
constants
"""

# Keys for outermost portion in output JSON
JSON_PROPERTY_URLS = "urls"
JSON_PROPERTY_RAW_KEY = "raw_key"
JSON_PROPERTY_PROCESSED_KEY = "processed_key"
JSON_PROPERTY_VALUES = "values"

# Keys for values portion in output JSON
JSON_PROPERTY_RAW_VALUE = "raw_value"
JSON_PROPERTY_VALUE_TYPE = "value_type"
JSON_PROPERTY_PROCESSED_VALUE = "processed_value"

# Keys for processed date and numeric values in output JSON
JSON_PROPERTY_DAY = "day"
JSON_PROPERTY_MONTH = "month"
JSON_PROPERTY_YEAR = "year"
JSON_PROPERTY_NUMBER = "numeric_value"

# Mapping of months to their numeric values
MONTH_TO_INT_MAPPING = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12
}

# Unit suffixes to their multipliers
UNIT_SUFFIX_TO_MULTIPLIER_MAPPING = {
    "k": 10**3, "thousand": 10**3,
    "m": 10**6, "mil": 10**6, "million": 10**6,
    "b": 10**9, "bil": 10**9, "billion": 10**9
}

# Trailing pucntionation to strip
TRAILING_PUNC_TO_STRIP = {',', ':', ';', '→', '←'}

# Keys for system-created elements containing URLs
ELEMENT_KEY_IMAGE_SOURCES = "<IMAGE_SOURCES>"
ELEMENT_KEY_LINK_URLS = "<LINK_URLS>"

# Constants for parsing
STRIP_TAGS = ['small', 'b', 'i', 'span', 'sub', 'sup',
              'font']  # Tags we strip and pretend don't exist

# Regexes for extracting type info
SHORT_MONTH_REGEX_FRAGMENT = r"jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec"
LONG_MONTH_REGEX_FRAGMENT = r"january|february|march|april|may|june|july|august|september|october|november|december"
DAY_REGEX = r"((0?[1-9]|[12][0-9]|3[01])(st|nd|rd|th)?)"
MONTH_REGEX = r"((0?[1-9]|1[0-2])|(" + SHORT_MONTH_REGEX_FRAGMENT + \
    "|" + LONG_MONTH_REGEX_FRAGMENT + "))"
YEAR_REGEX = r"(\d{2}|\d{4})"
DELIMITER_REGEX = r"([-./\, ]|, )"

DD_MM_YYYY_REGEX = r"^(" + DAY_REGEX + DELIMITER_REGEX + \
    MONTH_REGEX + DELIMITER_REGEX + YEAR_REGEX + ")$"
MM_DD_YYYY_REGEX = r"^(" + MONTH_REGEX + DELIMITER_REGEX + \
    DAY_REGEX + DELIMITER_REGEX + YEAR_REGEX + ")$"

NUMBER_REGEX = r"^(([0-9]*[.]?[0-9]+)[ -]?(thousand|million|billion|k|m|b|mil|bil)?)$"

# Type constants
VALUE_TYPE_STRING = "string"
VALUE_TYPE_DATE = "date"
VALUE_TYPE_NUMBER = "number"
