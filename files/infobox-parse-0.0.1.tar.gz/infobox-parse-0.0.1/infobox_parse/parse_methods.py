import ast

from functools import reduce

from bs4 import BeautifulSoup

from .post_process import post_process_infobox
from .shared_methods import extract_urls, extract_raw_text, create_key_value_json

#########################################
#########################################
#        Initialization Methods         #
#########################################
#########################################


def extract_infobox(html_string, key_dict, type_dict):

    def inner_extract_infobox(soup):
        try:
            # Attempt to parse from an <aside> first
            infobox = extract_infobox_from_aside(soup)
            if (infobox is not None) and (len(infobox) > 0):
                return infobox

            # If above failed, attempt to parse from <div>
            infobox = extract_infobox_from_div(soup)
            if (infobox is not None) and (len(infobox) > 0):
                return infobox

            # If above failed, attempt to parse from <table>
            infobox = extract_infobox_from_table(soup)
            if (infobox is not None) and (len(infobox) > 0):
                return infobox

        # If something went wrong or we didn't extract anything, return None
        except:
            return None
        return None

    html_soup = BeautifulSoup(html_string, 'html.parser')
    infobox = inner_extract_infobox(html_soup)
    if infobox is not None:
        post_process_infobox(infobox, key_dict, type_dict)
    return infobox


# Converts a dict like {key: [v1, v2]} to {v1: key, v2: key}. Assumes values are unique.
def invert_dict(d):
    inv = {}
    for key, val_list in d.items():
        for val in val_list:
            inv[val] = key
    return inv


# Dict that maps similar keys to a common key (e.g. 'writer' -> 'writer(s)', 'writers' -> 'writer(s)')
def create_key_mapping_dict(key_mapping_file_path):
    with open(key_mapping_file_path, 'r') as f:
        # key_mapping = ast.literal_eval(f.readlines())
        json_string = reduce(lambda a, b: f"{a}{b}", f.readlines())
        key_mapping = ast.literal_eval(json_string)
    key_mapping = invert_dict(key_mapping)
    return key_mapping


# Maps common keys to their associated type (e.g. 'writer(s)' -> 'person, 'director(s)' -> 'person)
def create_type_mapping_dict(type_mapping_file_path):
    with open(type_mapping_file_path, 'r') as f:
        json_string = reduce(lambda a, b: f"{a}{b}", f.readlines())
        type_mapping = ast.literal_eval(json_string)
    type_mapping = invert_dict(type_mapping)
    return type_mapping


#########################################
#########################################
#         Aside-Parsing Methods         #
#########################################
#########################################

def extract_infobox_from_aside(soup):
    # Attempt to extract the tag: <aside class="portable-infobox">
    infobox = soup.find("aside", {"class": "portable-infobox"})
    if infobox is None:
        return None

    # This list will store the keys/values we extract
    extracted = []

    # Iterate through each section of the infobox, which could contain tables or divs
    for section in infobox.findChildren("section", recursive=False):

        # Parse any divs in the section
        for div in section.findChildren("div", recursive=False):

            # Extract the key:values pair from the div. If successful, append it
            key_values_json = parse_aside_div(div)
            if key_values_json is not None:
                extracted.append(key_values_json)

        # # Parse any tables in the section
        # for table in section.findChildren("table", recursive=False):
        #     table_extract = parse_table(table)
        #     # Add all extracted elements except the url ones
        #     extracted += [elem for elem in table_extract if JSON_PROPERTY_PROCESSED_KEY not in elem]

    # Some elements of the infobox might be in a <div> without a <section>
    for div in infobox.findChildren("div", recursive=False):
        key_values_json = parse_aside_div(div)
        if key_values_json is not None:
            extracted.append(key_values_json)

    # Extract all urls from the infobox
    extract_urls(infobox, extracted)

    # Return our accumulated key:values pairs
    return extracted


# Only works for parsing <div>'s inside an <aside>
def parse_aside_div(div):
    # Extract the key, which is always(?) in a <h3> tag.
    h3_containing_key = div.findChild("h3")
    key_urls_pair = extract_raw_text(h3_containing_key)
    if (key_urls_pair is None) or (len(key_urls_pair) != 1):
        return None  # If don't parse exactly 1 key, return None
    key, key_urls = key_urls_pair[0]

    # Extract the value, which is always(?) in a <div> tag
    div_containing_values = div.findChild("div")
    value_urls_pairs = extract_raw_text(div_containing_values)
    if (value_urls_pairs is None) or (len(value_urls_pairs) == 0):
        return None  # If don't parse any values, return None

    # Create JSON for key:values
    return create_key_value_json(key, key_urls, value_urls_pairs)


#########################################
#########################################
#          Div-Parsing Methods          #
#########################################
#########################################

def extract_infobox_from_div(soup):
    # Attempt to extract the tag: <div class="infobox">
    info_div = soup.find("div", {"class": "infobox"})
    if info_div is None:
        return None

    # This list will store the keys/values we extract
    extracted = []

    # Iterate through each <div> in the infobox <div>
    for row in info_div.findChildren("div", recursive=False):

        # Ensure row contains 2 inner divs: 1 containing key, 1 containing values
        row_elements = row.findChildren("div", recursive=False)
        if len(row_elements) != 2:
            continue

        # Extract the key; continue on failure
        key_urls_pair = extract_raw_text(row_elements[0])
        if (key_urls_pair is None) or (len(key_urls_pair) != 1):
            continue
        key, key_urls = key_urls_pair[0]

        # Extract the values; continue on failure
        value_urls_pairs = extract_raw_text(row_elements[1])
        if (value_urls_pairs is None) or (len(value_urls_pairs) == 0):
            continue

        # Create JSON for key:values, and append it if valid
        key_values_json = create_key_value_json(
            key, key_urls, value_urls_pairs)
        if key_values_json is None:
            continue
        extracted.append(key_values_json)

    # Extract all urls from the infobox
    extract_urls(info_div, extracted)

    # Return our accumulated key:values pairs
    return extracted


#########################################
#########################################
#        Table-Parsing Methods          #
#########################################
#########################################

# Many different types of tables can be infoboxes. The types I have covered
# in this method include: class={infobox, wikia-infobox, "questdetails"},
# as well as any table with a "float:right" attribute. Tables are examined in a
# fallback manner, meaning once an infobox has been successfully extracted from
# a table, execution returns. If it fails, it will attempt to extract an infobox
# from the next type of table.
def extract_infobox_from_table(soup):
    # Extract all the tables in the order we wish to analyze them
    tables = soup.findChildren("table", {"class": "infobox"}) + \
        soup.findChildren("table", {"class": "wikia-infobox"}) + \
        soup.findChildren("table", {"class": "questdetails"}) + \
        soup.findChildren("table", attrs={
            'style': lambda s: (s is not None) and ('float:right' in s.replace(" ", "").lower())
        })

    # If no tables were found, return None
    if len(tables) == 0:
        return None

    # Attempt to parse each table. Once we successfully parse a table, return the result.
    for table_html in tables:
        infobox = parse_table(table_html)
        if infobox is not None:
            return infobox

    # If we couldn't extract anything, return an empty list
    return []


def parse_table(table_html):
    # This list will store the keys/values we extract
    extracted = []

    # Remove any <thead> or <tbody> tags
    for tag in ['thead', 'tbody']:
        for match in table_html.findAll(tag):
            match.unwrap()
    table_html = BeautifulSoup(str(table_html), 'html.parser').find()

    # Assume each row of the table corresponds to a key:values pair
    for row in table_html.findChildren("tr", recursive=False):

        # Keys and values could be in <th> or <td> tags, so extract them all
        row_elements = row.findChildren("th", recursive=False)
        row_elements += row.findChildren("td", recursive=False)

        # Case if there's only 1 tag (column) in the row
        if len(row_elements) == 1:

            # Attempt to parse tables from the tag (nested tables)
            tables = row_elements[0].findChildren("table", recursive=False)
            if len(tables) > 0:
                for table in tables:
                    extracted += parse_table(table)

        # If row contains 2 elements, attempt to parse a key:values pair
        elif len(row_elements) == 2:

            # Parse the key from first row element; continue on failure
            key_urls_pair = extract_raw_text(row_elements[0])
            if (key_urls_pair is None) or (len(key_urls_pair) == 0):
                continue
            key, key_urls = key_urls_pair[0]

            # Parse the values from the second row element; continue on failure
            value_urls_pairs = extract_raw_text(row_elements[1])
            if (value_urls_pairs is None) or (len(value_urls_pairs) == 0):
                continue

            # Create the key:values JSON; append if valid
            key_values_json = create_key_value_json(
                key, key_urls, value_urls_pairs)
            if key_values_json is None:
                continue
            extracted.append(key_values_json)

    # Extract all urls from the infobox
    extract_urls(table_html, extracted)

    # Return our accumulated key:values pairs
    return extracted
