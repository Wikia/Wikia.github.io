import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

packages = ['infobox_parse']
install_requires = ['beautifulsoup4==4.8.*']

setuptools.setup(
    author="Fandom Engineering",
    description="Parsing library for Fandom infoboxes.",
    install_requires=install_requires,
    long_description_content_type="text/markdown",
    long_description=long_description,
    name="infobox-parse",
    packages=packages,
    python_requires='>=3.6',
    url="https://github.com/Wikia/infobox-parse",
    version="0.0.1",
)
