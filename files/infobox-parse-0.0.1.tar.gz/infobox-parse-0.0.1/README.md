# Infobox Parse

This library is based on the work done by Tanner Gilligan of Unbox Research.