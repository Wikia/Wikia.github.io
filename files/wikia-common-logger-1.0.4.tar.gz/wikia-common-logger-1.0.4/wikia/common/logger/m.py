import json_logger
import logging

json_logger.configure("x", "1.0", logging.INFO)

logger = logging.getLogger("celery-purger-worker")

logger.info("aaaa", extra={'aaa': 123})
logger.warn("bbbb", extra={'bbbb': 'ccc'})
